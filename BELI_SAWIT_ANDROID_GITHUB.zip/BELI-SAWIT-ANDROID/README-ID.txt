BELI SAWIT - PROYEK ANDROID

Isi proyek ini membungkus aplikasi offline Beli_Sawit.html ke dalam aplikasi Android.

CARA MEMBUAT APK MELALUI GITHUB ACTIONS:
1. Unggah SELURUH ISI folder proyek ini ke repositori GitHub bernama BELI-SAWIT-ANDROID.
   Penting: sertakan folder tersembunyi .github/workflows/build-apk.yml.
2. Setelah file masuk ke cabang main, buka tab Actions pada repositori.
3. Pilih workflow "Buat APK BELI SAWIT" lalu tekan Run workflow jika belum berjalan otomatis.
4. Tunggu sampai workflow berstatus hijau/success.
5. Buka hasil run tersebut, cari bagian Artifacts, lalu unduh BELI-SAWIT-APK.
6. Ekstrak ZIP hasil unduhan dan pasang app-debug.apk di Android.

Catatan:
- Build dilakukan oleh GitHub Actions, bukan oleh HP.
- APK ini adalah versi debug untuk pemasangan langsung, bukan rilis Play Store.
- Data aplikasi disimpan lokal pada perangkat. Hapus data aplikasi dapat menghapus data yang belum dicadangkan.
- Fitur cetak menggunakan layanan cetak Android.
